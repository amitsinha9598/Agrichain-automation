```java
package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
    WebDriver driver;

    By inputBox = By.id("input-text");      // assumed ID
    By submitButton = By.id("submit-btn");  // assumed ID

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterText(String text) {
        driver.findElement(inputBox).clear();
        driver.findElement(inputBox).sendKeys(text);
    }

    public void clickSubmit() {
        driver.findElement(submitButton).click();
    }
}
```
