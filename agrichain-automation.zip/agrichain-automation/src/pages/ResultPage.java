```java
package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ResultPage {
    WebDriver driver;

    By resultText = By.id("output"); // assumed ID

    public ResultPage(WebDriver driver) {
        this.driver = driver;
    }

    public String getResult() {
        return driver.findElement(resultText).getText();
    }
}
```
