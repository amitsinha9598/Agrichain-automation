```java
package tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.ResultPage;
import utils.WebDriverFactory;

public class LongestSubstringTest {
    WebDriver driver;
    HomePage homePage;
    ResultPage resultPage;

    @BeforeClass
    public void setUp() {
        driver = WebDriverFactory.createDriver();
        homePage = new HomePage(driver);
        resultPage = new ResultPage(driver);
    }

    @Test
    public void testValidInput() {
        homePage.enterText("abcabcbb");
        homePage.clickSubmit();
        String output = resultPage.getResult();
        Assert.assertEquals(output, "3", "Expected output is 3");
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
```
